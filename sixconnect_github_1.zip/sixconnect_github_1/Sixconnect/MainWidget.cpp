#include "MainWidget.h"
#include "ui_widget.h"
#include <QPushButton>

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent)
{
    //设置玩家对决、人机模式、双机模式、退出游戏按钮
    players.setParent(this);
    players.setText("玩家对决");
    players.show();
    players.move(310,70);

    manmachine.setParent(this);
    manmachine.setText("人机模式");
    manmachine.show();
    manmachine.move(310,110);

    machines.setParent(this);
    machines.setText("双机模式");
    machines.show();
    machines.move(310,150);

    exit.setParent(this);
    exit.setText("退出游戏");
    exit.show();
    exit.move(310,190);

    //实现各个按钮功能

    //跳转至玩家对战窗口,以及处理子窗口跳转回来的信号
    connect(&players,&QPushButton::released,this,&MainWidget::changeWinpvp);
    connect(&w,&Pvp::pvptomain,this,&MainWidget::dealpvp);

    //跳转至人机对战窗口，以及处理子窗口跳转回来的信号
    connect(&manmachine,&QPushButton::released,this,&MainWidget::changeWinpvc);
    connect(&v,&pvc::pvctomain,this,&MainWidget::dealpvc);

    //跳转至双机模式窗口,以及处理子窗口跳转回来的信号
    connect(&machines,&QPushButton::released,this,&MainWidget::changeWincvc);
    connect(&u,&Cvc::cvctomain,this,&MainWidget::dealcvc);

    //退出游戏按钮
    connect(&exit,&QPushButton::clicked,this,&MainWidget::close);
}

//双人模式自定义信号：本窗口隐藏，子窗口显示，及其逆过程
void MainWidget::changeWinpvp()
{
    w.show();
    this->hide();
}

void MainWidget::dealpvp()
{
    w.hide();
    this->show();
}

//人机对战自定义信号：本窗口隐藏，子窗口显示，及其逆过程
void MainWidget::changeWinpvc()
{
    v.show();
    this->hide();
}

void MainWidget::dealpvc()
{
    v.hide();
    this->show();
}

//双机模式自定义信号：本窗口隐藏，子窗口显示，及其逆过程
void MainWidget::changeWincvc()
{
    u.show();
    this->hide();
}

void MainWidget::dealcvc()
{
    u.hide();
    this->show();
}

MainWidget::~MainWidget()
{
}
