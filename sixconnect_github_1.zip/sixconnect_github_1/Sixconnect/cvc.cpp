#include "cvc.h"

Cvc::Cvc(QWidget *parent) : QWidget(parent)
{
    //切换回主窗口
    this->setWindowTitle("玩家对战");
    backcvc.setParent(this);
    backcvc.setText("返回");

    //处理返回的按钮和信号
    connect(&backcvc,&QPushButton::clicked,this,&Cvc::sendslot);
}

void Cvc::sendslot()
{
    emit cvctomain();
}
