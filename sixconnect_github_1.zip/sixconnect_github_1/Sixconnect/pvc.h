#ifndef PVC_H
#define PVC_H

#include <QWidget>
#include <QPushButton>

class pvc : public QWidget
{
    Q_OBJECT
public:
    explicit pvc(QWidget *parent = nullptr);

    void sendslot();

signals:
    void pvctomain();


public slots:

private:
    QPushButton backpvc;
};

#endif // PVC_H
