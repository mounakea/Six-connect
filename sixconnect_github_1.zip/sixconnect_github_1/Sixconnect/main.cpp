#include "MainWidget.h"
#include <QApplication>
#include <QPainter>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWidget w;
    w.show();
    w.setFixedSize(450,280);

    //显示窗口标题
    w.setWindowTitle("六子棋Six Connect");

    return a.exec();
}
//接下来是main页面的图案
void MainWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/bk_rect"));
}
