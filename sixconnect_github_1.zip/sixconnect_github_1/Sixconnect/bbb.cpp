#include "bbb.h"

bbb::bbb(QWidget *parent) : QWidget(parent)
{

}
