#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QPushButton>
#include "pvp.h"
#include "pvc.h"
#include "cvc.h"

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = nullptr);
    ~MainWidget();
    void changeWinpvp();
    void changeWinpvc();
    void changeWincvc();
    void dealpvp();
    void dealpvc();
    void dealcvc();

protected:
    void paintEvent(QPaintEvent *);

private:
    QPushButton players;
    QPushButton manmachine;
    QPushButton machines;
    QPushButton exit;

    Pvp w;
    pvc v;
    Cvc u;

    Ui::MainWidget *ui;
};

#endif // WIDGET_H
