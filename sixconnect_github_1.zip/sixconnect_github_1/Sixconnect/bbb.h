#ifndef BBB_H
#define BBB_H

#include <QWidget>

class bbb : public QWidget
{
    Q_OBJECT
public:
    explicit bbb(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // BBB_H