#ifndef CHESSBOARD_H
#define CHESSBOARD_H
#include<QWidget>


class ChessBoard:public QWidget
{
    Q_OBJECT
public:
    ChessBoard();
    //设置棋盘的规模（20*20），预备在二维数组的每个点上赋值0，1，2分别表示空、黑子、白子
    int Boardscale[20][20];

};

#endif // CHESSBOARD_H
