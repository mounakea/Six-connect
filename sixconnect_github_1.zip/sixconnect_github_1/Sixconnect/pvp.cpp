#include "pvp.h"

Pvp::Pvp(QWidget *parent) : QWidget(parent)
{
    //切换回主窗口
    this->setWindowTitle("玩家对战");
    backpvp.setParent(this);
    backpvp.setText("返回");

    //处理返回的按钮和信号
    connect(&backpvp,&QPushButton::clicked,this,&Pvp::sendslot);
}

void Pvp::sendslot()
{
    emit pvptomain();
}
