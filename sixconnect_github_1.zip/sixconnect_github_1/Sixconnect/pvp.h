#ifndef PVP_H
#define PVP_H

#include <QWidget>
#include <QPushButton>

class Pvp : public QWidget
{
    Q_OBJECT
public:
    explicit Pvp(QWidget *parent = nullptr);

    void sendslot();

signals:
    void pvptomain();

public slots:

private:
    QPushButton backpvp;
};

#endif // PVP_H
