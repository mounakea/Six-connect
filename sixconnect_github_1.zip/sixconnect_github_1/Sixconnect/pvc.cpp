#include "pvc.h"

pvc::pvc(QWidget *parent) : QWidget(parent)
{
    //切换回主窗口
    this->setWindowTitle("人机对战");
    backpvc.setParent(this);
    backpvc.setText("返回");

    //处理返回的按钮和信号
    connect(&backpvc,&QPushButton::clicked,this,&pvc::sendslot);
}

void pvc::sendslot()
{
    emit pvctomain();
}
