#include "cvc.h"
#include <QPainter>
#include <QPen>

Cvc::Cvc(QWidget *parent) : QWidget(parent)
{
    //切换回主窗口
    this->setWindowTitle("双机模式");
    backcvc.setParent(this);
    backcvc.setText("返回");

    //处理返回的按钮和信号
    connect(&backcvc,&QPushButton::clicked,this,&Cvc::sendslot);
}

void Cvc::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPen pen;
    pen.setWidth(3);
    p.setPen(pen);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/gamebk"));
    int i;
    for(i=0;i<=19;i++)
    {
        p.drawLine(32,50+24*i,32+19*24,50+24*i);
    }
    for(i=0;i<=19;i++)
    {
        p.drawLine(32+24*i,50,32+24*i,50+19*24);
    }
}

void Cvc::sendslot()
{
    emit cvctomain();
}
