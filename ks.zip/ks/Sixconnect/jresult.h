#ifndef JRESULT_H
#define JRESULT_H

#include <QWidget>

class Jresult : public QWidget
{
    Q_OBJECT
public:
    explicit Jresult(QWidget *parent = nullptr);

    int jresult(int array[20][20]);

    int crossway(int array[20][20]);

    int lengthway(int array[20][20]);

    int rd(int array[20][20]);

    int ld(int array[20][20]);

signals:

public slots:
};

#endif // JRESULT_H
