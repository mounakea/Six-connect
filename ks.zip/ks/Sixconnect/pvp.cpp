#include "pvp.h"
#include "pvpchess.h"
#include "jresult.h"
#include "jvalid.h"
#include <QPainter>
#include <QPen>
#include <QMouseEvent>
#include <QtDebug>

Pvp::Pvp(QWidget *parent) : QWidget(parent)
{
    Agame.clear();
    //切换回主窗口
    this->setWindowTitle("玩家对决");
    backpvp.setParent(this);
    backpvp.setText("返回");

    //处理返回的按钮和信号
    connect(&backpvp,&QPushButton::clicked,this,&Pvp::sendslot);
}



//获取鼠标坐标
void Pvp::mouseReleaseEvent(QMouseEvent *ev)
{
    if (ev->button() != Qt::LeftButton) // 排除鼠标右键点击
    {
        return;
    }

    int i = ev->x();
    int j = ev->y();

    if(i>=32&&i<=32+19*24&&j>=50&&j<=50+19*24)
    {
        int cro,len;

        if((i-32)-(i-32)/24*24>12)
        {
            cro=(i-32)/24+1;
        }
        else {
            cro=(i-32)/24;
        }
        if((j-50)-(j-50)/24*24>12)
        {
            len=(j-50)/24+1;
        }
        else {
            len=(j-50)/24;
        }

        //在这里判断落子合法性，首先是不能重叠，再有就是不能禁手
        if(Pvpvalidty.overlap(Agame.chessboard,cro,len)&&Pvpvalidty.forbidden(Agame.chessboard,cro,len,Agame.get_player())<2)
        {
            Agame.set_chess(cro,len);
        }
        else if(Pvpvalidty.overlap(Agame.chessboard,cro,len)&&Pvpvalidty.forbidden(Agame.chessboard,cro,len,Agame.get_player())>=2)
        {
            qDebug() << "Game Over";
            if(Agame.get_player()==2)
            {
                QMessageBox::about(this,"禁手！","黑棋赢了");
                qDebug() << Pvpvalidty.forbidden(Agame.chessboard,cro,len,Agame.get_player());
            }
            else if(Agame.get_player()==1)
            {
                QMessageBox::about(this,"禁手！","白棋赢了");
                qDebug() << Pvpvalidty.forbidden(Agame.chessboard,cro,len,Agame.get_player());
            }
            Agame.clear();
        }
    }

    this->update();

}

//绘制棋盘和棋子
void Pvp::paintEvent(QPaintEvent *)
{
    QPainter p1(this);
    QPen pen1;
    pen1.setWidth(3);
    p1.setPen(pen1);
    p1.drawPixmap(0,0,width(),height(),QPixmap("../image/gamebk"));
    int i,j;
    for(i=0;i<=19;i++)
    {
        p1.drawLine(32,50+24*i,32+19*24,50+24*i);
    }
    for(i=0;i<=19;i++)
    {
        p1.drawLine(32+24*i,50,32+24*i,50+19*24);
    }
    QPainter p2(this);
    QPen pen2;
    pen2.setWidth(1);
    p2.setPen(pen2);
    QBrush brush_black;
    QBrush brush_white;
    brush_black.setColor(Qt::black);
    brush_black.setStyle(Qt::Dense1Pattern);
    brush_white.setColor(Qt::white);
    brush_white.setStyle(Qt::Dense1Pattern);
    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            if(Agame.get_chess(i,j)==1)
            {
                p2.setBrush(brush_black);
                p2.drawEllipse(QPoint(32+i*24,50+j*24),8,8);
            }
            else if(Agame.get_chess(i,j)==2)
            {
                p2.setBrush(brush_white);
                p2.drawEllipse(QPoint(32+i*24,50+j*24),8,8);
            }
        }
    }

    while(Pvpresult.jresult(Agame.chessboard)==1||Pvpresult.jresult(Agame.chessboard)==2)
    {
        qDebug() << "Game Over";
        if(Agame.get_player()==2)
        {
            QMessageBox::about(this,"游戏结束","黑棋赢了");
        }
        else if(Agame.get_player()==1)
        {
            QMessageBox::about(this,"游戏结束","白棋赢了");
        }
        //QMessageBox::about(this,"游戏结束","你赢了");
        Agame.clear();//必须要有这个清空盘面，不然会出现死循环的情况（为什么？？）
    }

    while(!Pvpresult.jresult(Agame.chessboard))
    {
        qDebug() << "Game Over";
        QMessageBox::about(this,"游戏结束","和棋");
        Agame.clear();//必须要有这个清空盘面，不然会出现死循环的情况（为什么？？）
    }
}

void Pvp::sendslot()
{
    emit pvptomain();
    Agame.clear();
}
