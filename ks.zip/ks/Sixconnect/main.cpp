#include "MainWidget.h"
#include <QApplication>
#include <QPainter>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWidget w;

    w.setFixedSize(450,280);

    //显示窗口标题
    w.setWindowTitle("六子棋Six Connect");

    w.show();

    return a.exec();
}
//接下来是main页面的图案
void MainWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/bk_rect"));
}
/*规则：
*1.对峙双方谁的六个棋子先连在一条线即为胜者。
*2.当有四个子连成一条直线时，就应采取防守，堵住四子的一端，否则就会输掉比赛。
*3.应当避免在比赛内出现四四禁手、五五禁手等情况，否则就会不小心输掉比赛。
*
*程序使用C/S架构
*（1）MFC/Qt编程实现server程序六子棋游戏界面，20*20格子；
*（2）编程实现server本地端的鼠标点击依次放置黑白棋子，实现双人手动下棋；
*（3）编程实现自动判别下棋的合法性；
*60分起评
*（4）编程实现自动判别盘面输赢或者和棋；
*70分起评
*（5）编程实现server端的agent，实现本地人机、机机下棋；
*80分起评
*（6）编程实现client程序（console程序），与server端实时通信获取当前棋面信息，发送走下一步棋的棋面信息。（数据量不大，直接发送全部棋面数据，邻接矩阵）
*（7）编程实现server端的异步交互机制和下棋先后手的顺序机制；
*（8）在client中添加agent，实现两个agent同时连接对抗下棋，或者1个agent连接与server端的agent进行对抗。
*90分起评
*/
