#ifndef PVPCHESS_H
#define PVPCHESS_H

#include <QWidget>

class Pvpchess : public QWidget
{
    Q_OBJECT

private:


    int player_current=1;//当前选手，play1或play2，分别执黑和白

signals:

public:
    explicit Pvpchess(QWidget *parent = nullptr);

    int chessboard[20][20];

    void clear()
    {
        memset(chessboard, 0, sizeof (chessboard));

        player_current=1;//每一次清空当然包含先手重置为黑棋的操作。
    }

    void set_chess(int x,int y)
    {
        chessboard[x][y]=player_current;

        if(player_current==1)
        {
            player_current=2;
        }

        else if(player_current==2)
        {
            player_current=1;
        }
    }

    int get_chess(int x,int y)
    {
        return chessboard[x][y];
    }

    int get_player()
    {
        return player_current;
    }

public slots:
};

#endif // PVPCHESS_H
