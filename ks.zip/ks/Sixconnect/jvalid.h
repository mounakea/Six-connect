#ifndef JVALID_H
#define JVALID_H

#include <QWidget>
#include "jresult.h"

class Jvalid : public QWidget
{
    Q_OBJECT
public:
    explicit Jvalid(QWidget *parent = nullptr);

    bool overlap(int array [20][20] , int x , int y);

    int forbidden(int array [20][20],int x ,int y ,int player);

signals:

public slots:

private:
    Jresult Pvpresult;
};

#endif // JVALID_H
