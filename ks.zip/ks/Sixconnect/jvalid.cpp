#include "jvalid.h"
#include <QtDebug>

Jvalid::Jvalid(QWidget *parent) : QWidget(parent)
{

}

//判断重叠
bool Jvalid::overlap(int array [20][20] , int x , int y)
{
    if(array[x][y])
    {
        return 0;
    }
    return 1;
}

//判断禁手
/*对于每个落子，向八个方向延伸5格，形成4条相交线，判断是否存在4连（端点自由）或五连（至少一个端点自由）
 *如果枚举每种搭配形式，则情况太多
 * 所以设一个Int n = 0，每有一个4连（端点自由）或五连（至少一个端点自由）则n+1
 * 若n>=2则该棋是禁手
 * 但是延伸5格是理想情况，偶尔会有撞墙的情况，一开始想法是将棋盘分为内外圈，内圈正常算，外圈特殊算
 * 但其实这样想实在太复杂了
 * 可以把落子的四个方向视为独立的，各自判断延伸情况。
 * 写了一下发现遍历每一个方向判断该方向是否出现能增加n的情况实在太复杂
 * 所以类比于备选的判断输赢的方案，可以先初始化一个数组，包含了n增的所有形式，然后一一比对，看是否出现一样情形
 * 以黑棋为例
 * 011110  0101110  0110110  0111010
 * 0111110  01011110  01101110  01110110  01111010 2111110  21011110  21101110  21110110  21111010  0111112  01111012  01110112  01101112  01011112  0111112
 * 五颗子的情况其实可以简化为11111  101111  110111  111011  111101  111110且两端的2不超过1个
 * 因该考虑五子和四子的模型中是否有重叠的，比如一个判断7个数字一个判断6个数字，7完整的包含6，那么符合7的就被判断了两次
 * 我所设定的两组模型避免了这种情况：
 * 首先四子的都包含了首尾两个0，而五子的不考虑首尾，而在其后单独编写代码判断，这样确保了形式完全不同，不会出现重复判断的情况
 */
int Jvalid::forbidden(int Oarray [20][20],int x ,int y ,int player)
{
    int i , j , k , index , mid;
    int n = 0;
    int expandcro[11];
    int expandlen[11];
    int expandrd[11];
    int expandld[11];
    int bfour[4][7]={{0,1,1,1,1,0},{0,1,0,1,1,1,0},{0,1,1,0,1,1,0},{0,1,1,1,0,1,0}};
    int bfive[6][6]={{1,1,1,1,1},{1,0,1,1,1,1},{1,1,0,1,1,1},{1,1,1,0,1,1},{1,1,1,1,0,1},{1,1,1,1,1,0}};
    int wfour[4][7]={{0,2,2,2,2,0},{0,2,0,2,2,2,0},{0,2,2,0,2,2,0},{0,2,2,2,0,2,0}};
    int wfive[6][6]={{2,2,2,2,2},{2,0,2,2,2,2},{2,2,0,2,2,2},{2,2,2,0,2,2},{2,2,2,2,0,2},{2,2,2,2,2,0}};

    int array[20][20];

    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            array[i][j]=Oarray[i][j];
        }
    }

    array[x][y]=player;

    //如果落子后直接结束，这个优先级是最高的
    Pvpresult.jresult(array)!=3;
    return 0;

    //横
    if(y<=4)
    {
        k=0;
        for(i=0;i<=y+5;i++,k++)
        {
            expandcro[k]=array[x][i];
        }//注意循环结束时候k还会加一次1,k等于array中记录的数字的数量
    }
    else if(y>=15)
    {
        k=0;
        for(i=y-5;i<=19;i++,k++)
        {
            expandcro[k]=array[x][i];
        }
    }
    else {
        k=0;
        for(i=y-5;i<=y+5;i++,k++)
        {
            expandcro[k]=array[x][i];
        }
    }

    //横判断
    if(player==1)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandcro[index]==bfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandcro[mid]==bfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=1;index<k-4;index++)
            {
                if(expandcro[index]==bfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandcro[mid]==bfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandcro[mid-6]==2&&expandcro[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandcro[mid-7]==2&&expandcro[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(player==2)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandcro[index]==wfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandcro[mid]==wfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandcro[index]==wfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandcro[mid]==wfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandcro[mid-6]==1&&expandcro[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandcro[mid-7]==1&&expandcro[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    //竖
    if(x<=4)
    {
        k=0;
        for(i=0;i<=x+5;i++,k++)
        {
            expandlen[k]=array[i][y];
        }
    }
    else if(x>=15)
    {
        k=0;
        for(i=x-5;i<=19;i++,k++)
        {
            expandlen[k]=array[i][y];
        }
    }
    else {
        k=0;
        for(i=x-5;i<=x+5;i++,k++)
        {
            expandlen[k]=array[i][y];
        }
    }

    //竖判断
    if(player==1)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandlen[index]==bfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandlen[mid]==bfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandlen[index]==bfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandlen[mid]==bfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandlen[mid-6]==2&&expandlen[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandlen[mid-7]==2&&expandlen[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(player==2)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandlen[index]==wfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandlen[mid]==wfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandlen[index]==wfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandlen[mid]==wfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandlen[mid-6]==1&&expandlen[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandlen[mid-7]==1&&expandlen[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    //rd
    if(x<=y)
    {
        if(x<=4)
        {
            k=0;
            for(i=0,j=y-x;i<=x+5&&j<=19;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
        else if (y>=15&&x>4)
        {
            k=0;
            for(i=x-5,j=y-5;j<=19;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
        else {
            k=0;
            for(i=x-5,j=y-5;i<=x+5;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
    }
    if(x>y)
    {
        if(y<=4)
        {
            k=0;
            for(i=x-y,j=0;j<=y+5&&i<=19;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
        else if(x>=15&&y>4)
        {
            k=0;
            for(i=x-5,j=y-5;j<=19;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
        else {
            k=0;
            for(i=x-5,j=y-5;i<=x+5;i++,j++,k++)
            {
                expandrd[k]=array[i][j];
            }
        }
    }

    //rd判断
    if(player==1)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandrd[index]==bfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandrd[mid]==bfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandrd[index]==bfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandrd[mid]==bfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandrd[mid-6]==2&&expandrd[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandrd[mid-7]==2&&expandrd[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(player==2)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandrd[index]==wfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandrd[mid]==wfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandrd[index]==wfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandrd[mid]==wfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandrd[mid-6]==1&&expandrd[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandrd[mid-7]==1&&expandrd[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    //ld
    if(x+y<=19)
    {
        if(x<=4)
        {
            k=0;
            for(i=0,j=y+x;i<=x+5&&j>=0;i++,j--,k++)
            {
                expandld[k]=array[i][j];
            }
        }
        else if(y<=4&&x>4)
        {
            k=0;
            for(i=x-5,j=y+5;j>=0;i++,j--,k++)
            {
                expandld[k]=array[i][j];
            }
        }
        else {
            k=0;
            for(i=x-5,j=y+5;i<=x+5;i++,j--,k++)
            {
                expandld[k]=array[i][j];
            }
        }
    }
    else {
        if(x>=15)
        {
            k=0;
            for(i=19,j=y+x-19;i>=x-5&&j<=19;i--,j++,k++)
            {
                expandld[k]=array[i][j];
            }
        }
        else if(y>=15&&x<15)
        {
            k=0;
            for(i=x+y-19,j=19;j>=y-5;i++,j--,k++)
            {
                expandld[k]=array[i][j];
            }
        }
        else {
            k=0;
            for(i=x-5,j=y+5;i<=x+5;i++,j--,k++)
            {
                expandld[k]=array[i][j];
            }
        }
    }

    //ld判断
    if(player==1)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandld[index]==bfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandld[mid]==bfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandld[index]==bfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandld[mid]==bfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandld[mid-6]==2&&expandld[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandld[mid-7]==2&&expandld[mid]==2))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(player==2)//区别黑白子
    {
        for(i=0;i<=3;i++)
        {
            for(index=0;index<k-5;index++)
            {
                if(expandld[index]==wfour[i][0])
                {
                    mid=index+1;j=1;
                    while(expandld[mid]==wfour[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==6)
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==7)
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        for(i=0;i<=5;i++)
        {
            for(index=0;index<k-4;index++)
            {
                if(expandld[index]==wfive[i][0])
                {
                    mid=index+1;j=1;
                    while(expandld[mid]==wfive[i][j])
                    {
                        mid++;j++;
                        if(!i)
                        {
                            if(j==5&&!(expandld[mid-6]==1&&expandld[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                        else if(i)
                        {
                            if(j==6&&!(expandld[mid-7]==1&&expandld[mid]==1))
                            {
                                n++;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    //最终判断
    return n;
}
