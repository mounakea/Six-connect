#include "jresult.h"

Jresult::Jresult(QWidget *parent) : QWidget(parent)
{

}

/*判断输赢（judge the result），该函数将调用四个函数，分别横向、纵向以及\和/判断是否分出输赢,
 * 还要考虑判断是否和棋。
 * 和棋0，黑赢1，白赢2，一定要注意可能没结束，返回3
 */
int crossway(int array[20][20]);

int lengthway(int array[20][20]);

int rd(int array[20][20]);

int ld(int array[20][20]);

int Jresult::jresult(int array[20][20])
{
    int i,j=0;
    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            if(!array[i][j])
            {
                break;
            }
        }
        if(!array[i][j])
        {
            break;
        }
    }//如果是break出来的，则说明棋盘上有空位，且array[i][j]此时为0，同时使得下面一条if语句无法执行，即不会返回和棋的情况
    if(array[i][j]&&i==19&&j==19&&crossway(array)==0&&lengthway(array)==0&&rd(array)==0&&ld(array)==0)
    {
        return 0;
    }
    else if(crossway(array))
    {
        int a = crossway(array);
        return a;
    }

    else if(lengthway(array))
    {
        int a = lengthway(array);
        return a;
    }

    else if(rd(array))
    {
        int a = rd(array);
        return a;
    }

    else if(ld(array))
    {
        int a = ld(array);
        return a;
    }
    else {
        return 3;
    }
}

/*横向
 * 一些解释：
 * 横向则不考虑纵向，从每行第一个开始向右遍历，空0黑1白2，非零即为落子，令x等于该子，
 * 向后数与该子相等的棋子的个数，最后一个编号减去1再减去第一个x的编号>=5则x获胜，返回x。
 */
int Jresult::crossway(int array[20][20])
{
    int i,j,k,x;
    for (i=0;i<=19;i++)
    {
        for(j=0;j<=14;j++)
        {
            if(array[i][j])
            {
                x=array[i][j];
                for(k=j+1;k<=19;k++)
                {
                    if(x==array[i][k])
                    {
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                if(k-1-j>=5)
                {
                    return x;
                }
            }
        }
    }
    return 0;
}

//纵向只需将横向的判定过程中的[][]内内容互换即可
int Jresult::lengthway(int array[20][20])
{
    int i,j,k,x;
    for (i=0;i<=19;i++)
    {
        for(j=0;j<=14;j++)
        {
            if(array[j][i])
            {
                x=array[j][i];
                for(k=j+1;k<=19;k++)
                {
                    if(x==array[k][i])
                    {
                        continue;
                    }
                    else
                    {
                        break;
                    }
                }
                if(k-1-j>=5)
                {
                    return x;
                }
            }
        }
    }
    return 0;
}

/*斜向，被我认为最为麻烦。
 * 。。。。。。。。。。；；；；；
 * 。。。。。。。。。。。；；；；
 * 。。。。。。。。。。。。；；；
 * 。。。。。。。。。。。。。；；
 * 。。。。。。。。。。。。。。；
 * 。。。。。。。。。。。。。。。
 * 。。。。。。。。。。。。。。。
 * 以15*15棋盘的上半部分为例，分号所表示的地方并不需要判断，同理左下角也存在这样的部分
 * （仅考虑斜向右下的,用rd表示right and down）
 */
int Jresult::rd(int array[20][20])
{
    int i,j,k,x,m,n;
    for(i=14;i>=0;i--)
    {
        for(j=0,k=i;j<=19-i;j++,k++)
        {
            if(array[j][k]&&(19-i-j)>=5)//不仅要非空棋，而且斜向还有剩余位置
            {
                x=array[j][k];
                m=j+1;n=k+1;
                for(;m<=19-i;m++,n++)
                {
                    if(x==array[m][n])
                    {
                        continue;
                    }
                    else {
                        break;
                    }
                }
                if(m-1-j>=5)
                {
                    return x;
                }
            }
        }
    }
    //至此对角线上半部分结束，当然，也包含了对角线
    for(i=1;i<=14;i++)
    {
        for(j=0,k=i;j<=19-i;j++,k++)
        {
            if(array[k][j]&&(19-i-j)>=5)
            {
                x=array[k][j];
                m=k+1;n=j+1;
                for(;m<=19;m++,n++)
                {
                    if(x==array[m][n])
                    {
                        continue;
                    }
                    else {
                        break;
                    }
                }
                if(n-1-j>=5)
                {
                    return x;
                }
            }
        }
    }
    return 0;
}

//左下右上，记为ld（left and down）
int Jresult::ld(int array[20][20])
{
    int i,j,k,x,m,n;
    for(i=5;i<=19;i++)
    {
        for(j=0,k=i;j<=i;j++,k--)
        {
            if(array[j][k]&&i-j>=5)
            {
                x=array[j][k];
                m=j+1;n=k-1;
                for(;n>=0;n--,m++)
                {
                    if(x==array[m][n])
                    {
                        continue;
                    }
                    else {
                        break;
                    }
                }
                if(m-1-j>=5)
                {
                    return x;
                }
            }
        }
    }
    for(i=1;i<=14;i++)
    {
        for(j=19,k=i;j>=i;j--,k++)
        {
            if(array[k][j]&&19-k>=5)
            {
                x=array[k][j];
                m=k+1;n=j-1;
                for(;m<=19;m++,n--)
                {
                    if(x==array[m][n])
                    {
                        continue;
                    }
                    else {
                        break;
                    }
                }
                if(m-1-k>=5)
                {
                    return x;
                }
            }
        }
    }
    return 0;
}
