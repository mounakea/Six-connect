#include "pvc.h"
#include <QPainter>
#include <QPen>

pvc::pvc(QWidget *parent) : QWidget(parent)
{
    //切换回主窗口
    this->setWindowTitle("人机对战");
    backpvc.setParent(this);
    backpvc.setText("返回");

    //处理返回的按钮和信号
    connect(&backpvc,&QPushButton::clicked,this,&pvc::sendslot);
}

void pvc::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPen pen;
    pen.setWidth(3);
    p.setPen(pen);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/gamebk"));
    int i;
    for(i=0;i<=19;i++)
    {
        p.drawLine(32,50+24*i,32+19*24,50+24*i);
    }
    for(i=0;i<=19;i++)
    {
        p.drawLine(32+24*i,50,32+24*i,50+19*24);
    }
}

void pvc::sendslot()
{
    emit pvctomain();
}
