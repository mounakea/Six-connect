/********************************************************************************
** Form generated from reading UI file 'mainwidge.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIDGE_H
#define UI_MAINWIDGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWidge
{
public:

    void setupUi(QWidget *MainWidge)
    {
        if (MainWidge->objectName().isEmpty())
            MainWidge->setObjectName(QStringLiteral("MainWidge"));
        MainWidge->resize(400, 300);

        retranslateUi(MainWidge);

        QMetaObject::connectSlotsByName(MainWidge);
    } // setupUi

    void retranslateUi(QWidget *MainWidge)
    {
        MainWidge->setWindowTitle(QApplication::translate("MainWidge", "MainWidge", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWidge: public Ui_MainWidge {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIDGE_H
