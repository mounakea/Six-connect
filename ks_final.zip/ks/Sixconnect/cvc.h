#ifndef CVC_H
#define CVC_H

#include <QWidget>
#include <QPushButton>

class Cvc : public QWidget
{
    Q_OBJECT
public:
    explicit Cvc(QWidget *parent = nullptr);

    void sendslot();

signals:
    void cvctomain();

public slots:

private:
    QPushButton backcvc;

protected:
    void paintEvent(QPaintEvent *);

};

#endif // CVC_H
