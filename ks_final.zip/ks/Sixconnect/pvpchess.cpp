#include "pvpchess.h"
#include <QPainter>
#include <QPen>

Pvpchess::Pvpchess(QWidget *parent) : QWidget(parent)
{

}
