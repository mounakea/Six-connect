#include "pvc.h"
#include "pvpchess.h"
#include "jresult.h"
#include "jvalid.h"
#include <QPainter>
#include <QPen>
#include <QMouseEvent>
#include <QtDebug>

pvc::pvc(QWidget *parent) : QWidget(parent)
{
    Bgame.clear();
    //切换回主窗口
    this->setWindowTitle("人机对战");
    backpvc.setParent(this);
    backpvc.setText("返回");

    //处理返回的按钮和信号
    connect(&backpvc,&QPushButton::clicked,this,&pvc::sendslot);
}

void pvc::assignsco(int array[20][20],int getpoint[20][20])
{
    int i,j,s,m,n,t;
    bool sh;//1为活，0为死
    //清零
    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            getpoint[i][j]=0;
        }
    }

    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            if(!array[i][j])
            {
                s=0;
                //上
                if(i)
                {
                    if(array[i-1][j]==2)
                    {
                        t=0;
                        for(m=i-1;m>=i-6&&m>=0;m--)
                        {
                            if(array[m][j]==array[i-1][j])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||array[m][j])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i-1][j]==1)
                    {
                        t=0;
                        for(m=i-1;m>=i-6&&m>=0;m--)
                        {
                            if(array[m][j]==array[i-1][j])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||array[m][j])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //下
                if(i<19)
                {
                    if(array[i+1][j]==2)
                    {
                        t=0;
                        for(m=i+1;m<=i+6&&m<=19;m++)
                        {
                            if(array[m][j]==array[i+1][j])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||array[m][j])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i+1][j]==1)
                    {
                        t=0;
                        for(m=i+1;m<=i+6&&m<=19;m++)
                        {
                            if(array[m][j]==array[i+1][j])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||array[m][j])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //左
                if(j)
                {
                    if(array[i][j-1]==2)
                    {
                        t=0;
                        for(n=j-1;n>=i-6&&n>=0;n--)
                        {
                            if(array[i][n]==array[i][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(n<0||array[i][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i][j-1]==1)
                    {
                        t=0;
                        for(n=j-1;n>=i-6&&n>=0;n--)
                        {
                            if(array[i][n]==array[i][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(n<0||array[i][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=1000;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //右
                if(j<19)
                {
                    if(array[i][j+1]==2)
                    {
                        t=0;
                        for(n=j+1;n<=i+6&&n<=19;n++)
                        {
                            if(array[i][n]==array[i][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(n>19||array[i][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i][j+1]==1)
                    {
                        t=0;
                        for(n=j+1;n<=i+6&&n<=19;n++)
                        {
                            if(array[i][n]==array[i][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(n>19||array[i][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //左上
                if(i&&j)
                {
                    if(array[i-1][j-1]==2)
                    {
                        t=0;
                        for(m=i-1,n=j-1;m>=i-6&&n>=j-6&&m>=0&&n>=0;m--,n--)
                        {
                            if(array[m][n]==array[i-1][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||n<0||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i-1][j-1]==1)
                    {
                        t=0;
                        for(m=i-1,n=j-1;m>=i-6&&n>=j-6&&m>=0&&n>=0;m--,n--)
                        {
                            if(array[m][n]==array[i-1][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||n<0||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //右下
                if(i<19&&j<19)
                {
                    if(array[i+1][j+1]==2)
                    {
                        t=0;
                        for(m=i+1,n=j+1;m<=i+6&&n<=j+6&&m<=0&&n<=0;m++,n++)
                        {
                            if(array[m][n]==array[i+1][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||n>19||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i+1][j+1]==1)
                    {
                        t=0;
                        for(m=i+1,n=j+1;m<=i+6&&n<=j+6&&m<=0&&n<=0;m++,n++)
                        {
                            if(array[m][n]==array[i+1][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||n>19||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //左下
                if(i&&j<19)
                {
                    if(array[i-1][j+1]==2)
                    {
                        t=0;
                        for(m=i-1,n=j+1;m>=i-6&&n<=j+6&&m>=0&&n<=19;m--,n++)
                        {
                            if(array[m][n]==array[i-1][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||n>19||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i-1][j+1]==1)
                    {
                        t=0;
                        for(m=i-1,n=j+1;m>=i-6&&n<=j+6&&m>=0&&n<=19;m--,n++)
                        {
                            if(array[m][n]==array[i-1][j+1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m<0||n>19||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //右上
                if(i<19&&j)
                {
                    if(array[i+1][j-1]==2)
                    {
                        t=0;
                        for(m=i+1,n=j-1;m<=i+6&&n>=j-6&&m<=19&&n>=0;m++,n--)
                        {
                            if(array[m][n]==array[i+1][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||n<0||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=25;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=85;
                            }
                            else {
                                s+=10000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=15;
                            }
                            else if(t==2)
                            {
                                s+=10;
                            }
                            else if(t==3)
                            {
                                s+=20;
                            }
                            else if(t==4)
                            {
                                s+=70;
                            }
                            else {
                                s+=10000;
                            }
                        }
                    }
                    else if(array[i+1][j-1]==1)
                    {
                        t=0;
                        for(m=i+1,n=j-1;m<=i+6&&n>=j-6&&m<=19&&n>=0;m++,n--)
                        {
                            if(array[m][n]==array[i+1][j-1])
                            {
                                t++;
                            }
                            else {
                                break;
                            }
                        }
                        if(m>19||n<0||array[m][n])
                        {
                            sh=0;
                        }
                        else {
                            sh=1;
                        }
                        if(sh)
                        {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=35;
                            }
                            else if(t==3)
                            {
                                s+=55;
                            }
                            else if(t==4)
                            {
                                s+=10000;
                            }
                            else {
                                s+=1000;
                            }
                        }
                        else {
                            if(t==1)
                            {
                                s+=5;
                            }
                            else if(t==2)
                            {
                                s+=15;
                            }
                            else if(t==3)
                            {
                                s+=35;
                            }
                            else if(t==4)
                            {
                                s+=90;
                            }
                            else {
                                s+=2000;
                            }
                        }
                    }
                }

                //赋分
                getpoint[i][j]=s;

            }
        }
    }

    //到这个位置时，已经填好了getpoint
}



//绘制棋盘和棋子
void pvc::paintEvent(QPaintEvent *)
{
    QPainter p1(this);
    QPen pen1;
    pen1.setWidth(3);
    p1.setPen(pen1);
    p1.drawPixmap(0,0,width(),height(),QPixmap("../image/gamebk"));
    int i,j;
    for(i=0;i<=19;i++)
    {
        p1.drawLine(32,50+24*i,32+19*24,50+24*i);
    }
    for(i=0;i<=19;i++)
    {
        p1.drawLine(32+24*i,50,32+24*i,50+19*24);
    }
    QPainter p2(this);
    QPen pen2;
    pen2.setWidth(1);
    p2.setPen(pen2);
    QBrush brush_black;
    QBrush brush_white;
    brush_black.setColor(Qt::black);
    brush_black.setStyle(Qt::Dense1Pattern);
    brush_white.setColor(Qt::white);
    brush_white.setStyle(Qt::Dense1Pattern);
    for(i=0;i<=19;i++)
    {
        for(j=0;j<=19;j++)
        {
            if(Bgame.get_chess(i,j)==1)
            {
                p2.setBrush(brush_black);
                p2.drawEllipse(QPoint(32+i*24,50+j*24),8,8);
            }
            else if(Bgame.get_chess(i,j)==2)
            {
                p2.setBrush(brush_white);
                p2.drawEllipse(QPoint(32+i*24,50+j*24),8,8);
            }
        }
    }


}

void pvc::checkwin()
{
    while(Pvcresult.jresult(Bgame.chessboard)==1||Pvcresult.jresult(Bgame.chessboard)==2)
    {
        qDebug() << "Game Over";
        if(Bgame.get_player()==2)
        {
            QMessageBox::about(this,"游戏结束","黑棋赢了");
        }
        else if(Bgame.get_player()==1)
        {
            QMessageBox::about(this,"游戏结束","白棋赢了");
        }
        //QMessageBox::about(this,"游戏结束","你赢了");
        Bgame.clear();//必须要有这个清空盘面，不然会出现死循环的情况（为什么？？）
    }

    while(!Pvcresult.jresult(Bgame.chessboard))
    {
        qDebug() << "Game Over";
        QMessageBox::about(this,"游戏结束","和棋");
        Bgame.clear();//必须要有这个清空盘面，不然会出现死循环的情况（为什么？？）
    }
}

//获取鼠标坐标
void pvc::mouseReleaseEvent(QMouseEvent *ev)
{
    if(Bgame.get_player()==1)//黑棋是先手，所以只有当初始状态下是黑先的时候才开始下棋
    {
        if (ev->button() != Qt::LeftButton) // 排除鼠标右键点击
        {
            return;
        }

        int i = ev->x();
        int j = ev->y();

        if(i>=32&&i<=32+19*24&&j>=50&&j<=50+19*24)
        {
            int cro,len;

            if((i-32)-(i-32)/24*24>12)
            {
                cro=(i-32)/24+1;
            }
            else {
                cro=(i-32)/24;
            }
            if((j-50)-(j-50)/24*24>12)
            {
                len=(j-50)/24+1;
            }
            else {
                len=(j-50)/24;
            }

          if(Pvcvalidty.overlap(Bgame.chessboard,cro,len))
            {
                Bgame.set_chess(cro,len);
            }
        }

        checkwin();//这是解决了之前的一个问题，每次下完黑棋立刻下白棋，就会出现黑已经胜利，白任然落子，再判断胜负的错误情况。

        /*这个while是解决另一个bug，当上一局的赢家是黑，即在此函数体的第一个checkwin函数就已经分出胜负的情况下，顺次走到剩余部分
        * 此时判断胜负函数结束时会立即将当前玩家置黑，所以此时电脑执黑，并且会立刻下一子，这显然是不符合规则的
        * 因此加一个while限定，判断完胜负后不管怎样，不会轮到电脑先手。
        */
        while(Bgame.get_player()==2) {
            assignsco(Bgame.chessboard,score);

            int max=score[0][0];

            int maxi=0,maxj=0;

            for(i=0;i<=19;i++)
            {
                for(j=0;j<=19;j++)
                {
                    if(score[i][j]>=max)
                    {
                        max=score[i][j];
                        maxi=i;
                        maxj=j;
                    }
                }
            }

            Bgame.set_chess(maxi,maxj);

            checkwin();

            this->update();
        }



    }
}
/*void pvc::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    QPen pen;
    pen.setWidth(3);
    p.setPen(pen);
    p.drawPixmap(0,0,width(),height(),QPixmap("../image/gamebk"));
    int i;
    for(i=0;i<=19;i++)
    {
        p.drawLine(32,50+24*i,32+19*24,50+24*i);
    }
    for(i=0;i<=19;i++)
    {
        p.drawLine(32+24*i,50,32+24*i,50+19*24);
    }
}*/

void pvc::sendslot()
{
    emit pvctomain();
    Bgame.clear();
}
