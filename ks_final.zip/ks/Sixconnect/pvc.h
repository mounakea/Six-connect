#ifndef PVC_H
#define PVC_H

#include <QWidget>
#include <QPushButton>
#include <QMessageBox>
#include "pvpchess.h"
#include "jvalid.h"
#include "jresult.h"

class pvc : public QWidget
{
    Q_OBJECT
public:
    explicit pvc(QWidget *parent = nullptr);

    void sendslot();

    void assignsco(int array[20][20],int getpoint[20][20]);

    void checkwin();

signals:
    void pvctomain();


public slots:

private:
    QPushButton backpvc;

    Pvpchess Bgame;

    Jvalid Pvcvalidty;

    Jresult Pvcresult;

    int score[20][20];

protected:
    void paintEvent(QPaintEvent *);

    void mouseReleaseEvent(QMouseEvent *ev);

};

#endif // PVC_H
