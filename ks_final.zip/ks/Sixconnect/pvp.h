#ifndef PVP_H
#define PVP_H

#include <QWidget>
#include <QPushButton>
#include <QMessageBox>
#include "pvpchess.h"
#include "jvalid.h"
#include "jresult.h"

class Pvp : public QWidget
{
    Q_OBJECT


public:
    explicit Pvp(QWidget *parent = nullptr);

    void sendslot();

    void checkwin();



signals:
    void pvptomain();

public slots:

private:
    QPushButton backpvp;

    Pvpchess Agame;

    Jvalid Pvpvalidty;

    Jresult Pvpresult;

protected:
    void paintEvent(QPaintEvent *);

    void mouseReleaseEvent(QMouseEvent *ev);

};

#endif // PVP_H
